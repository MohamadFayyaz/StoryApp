const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  ACCESS_TOKEN_KEY: 'accessToken',
  MAP_SERVICE_API_KEY: 'Q4nI7ps7VqeivqwR5L8h'
};

export default CONFIG;
